package com.attijaribank.suiviprojet.controller;

import com.attijaribank.suiviprojet.entites.Domaine;
import com.attijaribank.suiviprojet.entites.Seance;
import com.attijaribank.suiviprojet.service.DomaineService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping(value = "/domaine")
public class DomaineController {


    private final DomaineService domaineService;

    public DomaineController(DomaineService domaineService) {
        this.domaineService = domaineService;
    }

    @PostMapping("save-domaine")
    public void saveSeance(@RequestBody Domaine domaine) {
        domaineService.saveDomaine(domaine);

    }

    @GetMapping("domaines-list")
    public List<Domaine> allseances() {
        return domaineService.getDomaines();
    }


    @DeleteMapping("delete-domaine/{domaine-id}")
    public void deleteStudent(@PathVariable("domaine-id") long idDomaine, Domaine domaine) {
        domaine.setIdDomaine(idDomaine);
        domaineService.deleteDomaine(domaine);
    }


    @PostMapping("update-student/{student_id}")
    public boolean updateStudent(@RequestBody Seance seance, @PathVariable("seance_id") int seance_id) {
      /*  student.setStudent_id(seance_id);
        return studentservice.updateStudent(student);
		*/
        return false;
    }
}
