package com.attijaribank.suiviprojet.service;

import com.attijaribank.suiviprojet.entites.Domaine;
import com.attijaribank.suiviprojet.repository.DomaineRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DemandeService {


    private final DomaineRepository domaineRepository;

    public DemandeService(DomaineRepository domaineRepository) {
        this.domaineRepository = domaineRepository;
    }


    public Domaine saveProjet(Domaine domaine) {
        return domaineRepository.save(domaine);
    }


    public List<Domaine> getProjets() {
        return domaineRepository.findAll();
    }


    public void deleteProjet(Domaine domaine) {
        this.domaineRepository.delete(domaine);
    }


    public Optional<Domaine> getProjetByName(Domaine domaine) {

        return this.domaineRepository.findById(domaine.getIdDomaine());
    }


    public boolean updateStudent(Domaine domaine) {
        return false;
        //  projetRepository.(student);
    }


}
